#!/bin/bash
com=''
file1=''
file2=''

case $1 in
'cron_check')
    file1=/var/log/zabbix/cron_1.txt
    file2=/var/log/zabbix/cron_2.txt
    ;;
'cron_check_log')
    file1=/var/log/zabbix/zabbix_cron.log
    ;;
'tmp_check')
    com=`find /tmp -type f -executable -print`
    ;;
'pgsql_check')
    com=`find /var/lib/pgsql -type f -executable -print`
    ;;
'tmp_check_log')
    file1=/var/log/zabbix/zabbix_tmp.log
    ;;
'pgsql_check_log')
    file1=/var/log/zabbix/zabbix_pgsql.log
    ;;
'check_log_data')
    file1=/var/log/zabbix/zabbix_cron.log
    if [ -f $file1 ]; then
    com=`find /var/log/zabbix/zabbix_cron.log -type f -mmin -40`
    fi
    ;;
esac

cron_check_condition(){
    if cmp -s $file1 $file2; then
    echo 0
    else
    echo 1
    cp $file1 /var/log/zabbix/cron_old.txt
    find /var/spool/cron  -type f -exec cat {} \; > /var/log/zabbix/cron_1.txt
    fi
}

check_exec(){
    if [[ -n $com ]]; then
    echo 1
    else
    echo 0
    fi    
}

check_log(){
    if [ ! -f $file1 ]; then
    echo 0
    elif [ $(cat $file1) = 1 ]; then
    echo 1
    elif [ $(cat $file1) = 0 ]; then
    echo 0
    fi
}

check_log_date(){
    if [ ! -f $file1 ]; then
    echo 1
    elif [[ -n $com ]]; then
    echo 0
    else
    echo 1
    fi
}

if [ $1 = 'cron_check' ] && [ ! -f $file1 ]; then
find /var/spool/cron  -type f -exec cat {} \; > /var/log/zabbix/cron_1.txt
echo 0
elif [ $1 = 'cron_check' ] && [ -f $file1 ]; then
find /var/spool/cron  -type f -exec cat {} \; > /var/log/zabbix/cron_2.txt
cron_check_condition
elif [ $1 = 'tmp_check' ] || [ $1 = 'pgsql_check' ]; then
check_exec
elif [ $1 = 'cron_check_log' ] || [ $1 = 'tmp_check_log' ] || [ $1 = 'pgsql_check_log' ]; then
check_log
elif [ $1 = 'check_log_data' ]; then
check_log_date
fi
